 ![](http://i.imgur.com/1njY7qe.png)
###### Version 4.2.7, last updated 2017-06-28

### Description
This is a script that removes everything from the page except for the game itself and the nice-looking background, sets the Flash quality to "low" instead of "high", and sets the "wmode" parameter to "direct". *This reduces lag significantly.*

Games currently supported:
* [Arena](http://www.tetrisfriends.com/games/Live/game.php)
* [Sprint](http://www.tetrisfriends.com/games/Sprint/game.php)
* [Ultra](http://www.tetrisfriends.com/games/Ultra/game.php)
* [Survival](http://www.tetrisfriends.com/games/Survival/game.php)
* [Marathon](http://www.tetrisfriends.com/games/Marathon/game.php)

### How to install

##### _________________________________________________________________
##### **[Before you begin, install Adblock! This step reduces lag quite a bit by itself.](https://adblockplus.org/)**
___

#### Step 1: Get a Userscript Manager
* If you have Chrome, you can download the [Minimal Tetris Friends browser extension](https://chrome.google.com/webstore/detail/minimal-tetris-friends/jmcfgfebjmfodjnmgicmkpkbpbfelhki).

* If you have Firefox, get [Tampermonkey](https://addons.mozilla.org/en-US/firefox/addon/tampermonkey/).

* If you have Opera, get [Tampermonkey](https://addons.opera.com/en/extensions/details/tampermonkey-beta/).

* If you have Edge, get [Tampermonkey](https://www.microsoft.com/store/apps/9NBLGGH5162S).

* If you have Safari, get [Tampermonkey](https://safari.tampermonkey.net/tampermonkey.safariextz).

#### Step 2: Get the script
Go to [this page](https://raw.githubusercontent.com/morningpee/mtf/4.2.7/mtf.user.js). A dialog will pop up, click accept, and the script is installed.

### How to use

Visit the [Tetris Friends Arena](http://www.tetrisfriends.com/games/Live/game.php), and the script will do the rest. The DAS URL hack *does* work with this.

### What it should look like
Without the script installed, it will look something like this:
![](http://i.imgur.com/08BJLH4.png)

If the Minimal Tetris Arena script works, the page will look like this:
![](http://i.imgur.com/RL8nTBB.png)
So anyway, try it out and post results.

---
---
|||
--- | ---:
**[Download for Chrome](https://chrome.google.com/webstore/detail/minimal-tetris-friends/jmcfgfebjmfodjnmgicmkpkbpbfelhki)** | last updated 2015-06-23 |
|||
|||
**[Download for Firefox or Opera](https://raw.githubusercontent.com/morningpee/mtf/4.2.7/mtf.user.js)** | last updated 2017-06-28 |
|||size=1]last updated 2017-06-28[/size]
